class ScheduleError(Exception):
    pass
