database_file = 'data/projects.db'
window_icon_path = 'assets/window_icon.png'
